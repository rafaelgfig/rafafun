# rafafun
Conjunto de funções para agilizar algumas tarefas do dia-a-dia
